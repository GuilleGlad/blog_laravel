<div class="category-container">
    <ul>
        <li class="nav-item "><a href="#">Todo</a></li>         
            
        <li class="nav-item ">
            <a href="#"></a>
        </li>

        <li class="nav-item ">
            <a href="#">Todas las categorias</a>
        </li>

    </ul>
</div>